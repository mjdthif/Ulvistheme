  <?php

    get_header();

    woocommerce_content();

    get_footer();

   ?>

