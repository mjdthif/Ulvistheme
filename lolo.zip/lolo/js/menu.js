//jQuery(document).ready(function() {
// 
//	$(".burger-menu").on("click", function(){
//			
//	$(".site-nav").toggleClass("open");
//		
//	});
//  
// }); 

